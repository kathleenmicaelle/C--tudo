using System;

class Program
{
    static void Main()
    {
      Console.WriteLine("So roda no replit sorry kkkk");
      
        Console.Write("Digite um número inteiro: ");
        int numero = Convert.ToInt32(Console.ReadLine());

        string extenso = ConverteParaExtenso(numero);

        Console.WriteLine($"Número por extenso: {extenso}");
    }

    static string ConverteParaExtenso(int numero)
    {
        if (numero == 0)
        {
            return "zero";
        }

        if (numero < 0 || numero > 999)
        {
            return "Número fora do intervalo suportado";
        }

        string[] unidades = { "", "um", "dois", "três", "quatro", "cinco", "seis", "sete", "oito", "nove" };
        string[] especiaisDezAteDezenove = { "dez", "onze", "doze", "treze", "catorze", "quinze", "dezesseis", "dezessete", "dezoito", "dezenove" };
        string[] dezenas = { "", "dez", "vinte", "trinta", "quarenta", "cinquenta", "sessenta", "setenta", "oitenta", "noventa" };
        string[] centenas = { "", "cento", "duzentos", "trezentos", "quatrocentos", "quinhentos", "seiscentos", "setecentos", "oitocentos", "novecentos" };

        int centena = numero / 100;
        int dezena = (numero % 100) / 10;
        int unidade = numero % 10;

        string extensoCentena = centenas[centena];
        string extensoDezena = "";
        string extensoUnidade = "";

        if (dezena == 1)
        {
            extensoDezena = especiaisDezAteDezenove[unidade];
        }
        else
        {
            extensoDezena = dezenas[dezena];
            extensoUnidade = unidades[unidade];
        }

        // asos especiais
        if (centena == 1 && dezena == 0 && unidade == 0)
        {
            extensoCentena = "cem";
        }

        // Concatena
        string extenso = extensoCentena + (extensoCentena != "" && (extensoDezena != "" || extensoUnidade != "") ? " e " : "") + extensoDezena + (extensoDezena != "" && extensoUnidade != "" ? " e " : "") + extensoUnidade;

        return extenso;
    }
}
